export class LoginDTO {
    userName?: string;
    password?: string;
    platFormId?: string;
    deviceCategoryId?: string;
    timeZoneId?: string;
    ionicAppVersion?: string;
    deviceCode?: string;
    fcmTokenCode?: string;
    userAgent?: string;
}

export class LoginResponseDTO {

    UserId?: number;
    IsSuccess?: boolean;
  }

export class UserMetaDataResponseDTO {

    User: any = {};
    Roles: RoleDTO[] = [];
    Menues: any[] = [];
    Beats: any[] = [];
    Templates: any[] = [];
    CameraMan: any[] = [];
    Source:any[] =[];
    Reason:any=[];

}

export class RoleDTO {
    RoleId?: number;
    RoleName?: string;
    Sequence?: number;
    Menues?: any[] = [];
}

export class UserSlugRequestDTO {

    BeatId?: number;
    UserId?: number;
}


export class UserSlugResponseDTO {

    Slugs?: any[] = [];
    IsSuccess?: boolean;
}


export class ApiResponse{
    IsSuccess?:boolean;
    Data?: any;
    Message?:string;
    StatusCode?:number;
}