import { User } from "./models";
import { Config } from "./config";
import { Request, Response } from "express";
import { LoginDTO, LoginResponseDTO, UserSlugRequestDTO } from "./dtos";




//Initiallising node modules
const express = require("express");
const argv = require('minimist')(process.argv.slice(2));
const swagger = require("swagger-node-express");
const bodyParser = require("body-parser");
const sql = require("mssql");

const app = express();
const subpath  = express();

// Body Parser Middleware
app.use(bodyParser.json());

// Swagger
app.use("/v1", express);
swagger.setAppHandler(subpath);

swagger.setApiInfo({
    title: "example Express & Swagger API",
    description: "API to do something, manage something...",
    termsOfServiceUrl: "",
    contact: "yourname@something.com",
    license: "",
    licenseUrl: ""
});
app.use(express.static('dist'));

//CORS Middleware
app.use(function (req: Request, res:Response, next:any) {
    //Enabling CORS 
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
    next();
});

//Models
let UserModel = new User();



//Setting up server
let server = app.listen(process.env.PORT || 8080, function () {
    let port = server.address().port;
    console.log("App now running on port", port);
});




//Function to connect to database and execute query
let executeQuery = function (res:any, query:string) {
    sql.connect(Config.DBConfig, function (err:any) {
        if (err) {
            console.log("Error while connecting database :- " + err);
            res.send(err);
        }
        else {
            // create Request object
            let request = new sql.Request();
            // query to the database
            request.query(query, function (err:any, result:any) {
                if (err) {
                    console.log("Error while querying database :- " + err);
                    res.send(err);
                }
                else {
                    res.send(result);
                }
            });
        }
    });
}



//GET API
app.get("/", function (req: Request, res: Response) {
    res.sendfile(__dirname + '/dist/index.html');
    // let query = "select * from [user]";
    // res.send("done");
});

app.get("/api/nmsusers", function (req: Request, res: Response) {
    let userId = req.query.Id;
    if (!userId) {
        console.log()
        UserModel.GetAll(res);
    } else {
        UserModel.Get(res, userId);
    }
});

app.post("/api/user/login", function (req: Request, res: Response) {
    let params: LoginDTO = new LoginDTO();
    Object.assign(params, req.body);
    UserModel.Login(res, params);
});


app.post("/api/user/getUseMetaInfo", function (req: Request, res: Response) {
    let params: LoginResponseDTO = new LoginResponseDTO();
    Object.assign(params, req.body);
    UserModel.GetAuthenticateUserMetaInfo(res, params);
});

app.post("/api/nmsusers", function (req: Request, res: Response) {
    let UserModel = new User();
    UserModel.Insert(res, UserModel);
});

app.get("/api/user", function (req: Request, res: Response) {
    let query = "select * from [ApplicationUser]";
    executeQuery(res, query);
});

app.post("/api/user/getSlugByUser", function (req: Request, res: Response) {
    let params: UserSlugRequestDTO = new UserSlugRequestDTO();
    Object.assign(params, req.body);
    UserModel.GetSlugByUser(res, params);
});



subpath.get('/', function (req:Request, res:Response) {
    res.sendfile(__dirname + '/dist/index.html');
});

swagger.configureSwaggerPaths('', 'api-docs', '');

let domain = 'localhost';
if(argv.domain !== undefined)
    domain = argv.domain;
else
    console.log('No --domain=xxx specified, taking default hostname "localhost".');

// var applicationUrl = 'http://' + domain + ':' + app.get('port');
var applicationUrl = 'http://' + domain;
swagger.configure(applicationUrl, '1.0.0');
