import { UserMetaDataResponseDTO, UserSlugRequestDTO, UserSlugResponseDTO } from './../dtos/index';
import { BaseModel } from "./base-model";
import { Config } from "../config";
import { Response, response } from "express";
import { LoginDTO, LoginResponseDTO } from "../dtos";
let sql = require("mssql");


export class User extends BaseModel {
    constructor(
        IsActive?: boolean,
        IsDeleted?: boolean,
        CreatedAt?: string,
        CreatedBy?: string,
        ModifiedAt?: string,
        ModifiedBy?: string
    ) {

        super(
            IsActive,
            IsDeleted,
            CreatedAt,
            CreatedBy,
            ModifiedAt,
            ModifiedBy
        );
    }

    Id?: number = 0;
    UserName?: string = "rxzx";
    Password?: string = "Bol123";
    FullName?: string = "Raza";
    FirstName?: string = "Raza";
    Designation?: string = "Dev";
    FullNameUrdu?: string = "";
    FirstNameUrdu?: string = "";
    DesignationUrdu?: string = "";
    ProfilePicture?: string = "";
    LocationTitle?: string;
    Lat?: string = "";
    Long?: string = "";
    JobRoleId?: number = 1;
    LocationId?: number = 1;
    ShiftName?: string = "Morning";
    ShiftStartTime?: string = "";
    ShiftEndTime?: string = "";
    UserAgent?: string = "";


    public Insert(res: Response, dto: any) {
        BaseModel.Insert(res, Config.Tables.User, dto);
    }

    public Update(res: Response, dto: any) {
        BaseModel.Update(res, Config.Tables.User, dto);
    }

    public Get(res: any, Id: number) {
        BaseModel.Get(res, Config.Tables.User, Id);
    }

    public GetAll(res: any) {
        BaseModel.GetAll(res, Config.Tables.User);
    }


    public GetAuthenticateUserMetaInfo(res: Response, param: LoginResponseDTO) {

        sql.connect(Config.DBConfig, function (err: any) {
            if (err) {
                sql.close();
                console.log("Error while connecting database :- " + err);
                res.send(err);
            }
            else {
                let request = new sql.Request();
                let getMetaDataQuery = `EXEC [NMS_GetUserMetaInfoByUserId] ${param.UserId}`;
                request.multiple = true;
                request.query(getMetaDataQuery, function (err: any, metaData: any) {
                    if (err) {
                        console.log("Error while querying database :- " + err);
                        res.send(err);
                    } else {
                        res.send(User.mapGetUserMetaInfoResponse(metaData));
                        request.multiple = false;
                    }
                    sql.close();
                });
            }
        });
    }

    public Login(res: Response, params: LoginDTO) {
        sql.connect(Config.DBConfig, function (err: any) {
            if (err) {
                sql.close();
                console.log("Error while connecting database :- " + err);
                res.send(err);
            }
            else {
                // create Request object
                let request = new sql.Request();
                // query to the database
                let authenticateUserQuery = `EXEC [NMS_AuthenticateUser] 
                 @UserName ='${params.userName}', @Password='${params.password}' 
                ,@PlatformId='${params.platFormId ? params.platFormId : 1}'
                ,@DeviceCategoryId='${params.deviceCategoryId ? params.deviceCategoryId : 1}'
                ,@TimeZoneId='${params.timeZoneId ? params.timeZoneId : 1}'
                ,@IonicAppVersion='${params.ionicAppVersion ? params.ionicAppVersion : ""}'
                ,@DeviceCode='${params.deviceCode ? params.deviceCode : ""}'
                ,@FcmTokenCode='${params.fcmTokenCode ? params.fcmTokenCode : ""}'
                ,@UserAgent='${params.userAgent ? params.userAgent : ""}'
                `;

                request.query(authenticateUserQuery, function (err: any, userAuth: any) {
                    if (err) {
                        console.log("Error while querying database :- " + err);
                        sql.close();
                        res.send(err);
                    }
                    else {
                        if (userAuth.recordsets) {
                            userAuth = userAuth.recordsets[0];
                        }
                        let userId = userAuth[0].UserId;

                        let responseObject = new LoginResponseDTO();
                        responseObject.UserId = userId;
                        if (userId > 0)
                            responseObject.IsSuccess = true;
                        else
                            responseObject.IsSuccess = false;

                        sql.close();
                        res.send(responseObject);
                    }
                });
            }
        });


    }

    public GetSlugByUser(res: Response, params: UserSlugRequestDTO) {
        sql.connect(Config.DBConfig, function (err: any) {
            if (err) {
                sql.close();
                console.log("Error while connecting database :- " + err);
                res.send(err);
            }
            else {
                // create Request object
                let request = new sql.Request();
                // query to the database
                let reqQuery = `EXEC [NMS_GetSlug] 
                 @UserId ='${params.UserId}', @BeatId='${params.BeatId}'`;

                request.query(reqQuery, function (err: any, resp: any) {
                    if (err) {
                        sql.close();
                        console.log("Error while querying database :- " + err);
                        res.send(err);
                    }
                    else {
                        let responseObject = new UserSlugResponseDTO();
                        if (resp) {
                            responseObject.Slugs = resp;
                            responseObject.IsSuccess = true;
                        }
                        else {
                            responseObject.IsSuccess = false;
                        }
                        sql.close();
                        res.send(responseObject);
                    }
                });
            }
        });


    }

    public static mapGetUserMetaInfoResponse(metaData: any): UserMetaDataResponseDTO {
        let response = new UserMetaDataResponseDTO();
        if (metaData.recordsets && metaData.recordsets.length > 1) {
            metaData = metaData.recordsets;
        }
        response.User = metaData[0];
        response.Menues = metaData[2];
        response.Roles = metaData[1].map((Entity: any) => {
            if (!Entity.Menues) {
                Entity.Menues = [];
            }
            Entity.Menues.push(response.Menues.filter(x => x.RoleId === Entity.RoleId));
            return Entity;
        });
        response.Beats = metaData[3];
        response.Templates = metaData[4];
        response.CameraMan = metaData[5];
        response.Source = metaData[6];
        response.Reason = metaData[7];

        return response;

    }





}
