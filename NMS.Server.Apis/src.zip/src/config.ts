export const Config = {
    DBConfig: {
        user: "nms2019",
        password: "Nms@)!(",
        server: "52.28.232.38",
        database: "NMS2019"
    },
    Tables: {
        User: "User"
    }
}
